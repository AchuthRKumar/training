package com.demo.spring_rabbitmq_producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRabbitmqProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
